using dotnet.Entities;
using dotnet.Search;
using Microsoft.EntityFrameworkCore;

namespace dotnet.Data;

public sealed class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<Topic> Topics => Set<Topic>();
    public DbSet<Exchange> Exchanges => Set<Exchange>();
    public DbSet<Procedure> Procedures => Set<Procedure>();
    public DbSet<SearchDocument> SearchDocuments => Set<SearchDocument>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Topic>(entity =>
        {
            entity.ToTable("Topics");
            entity.HasKey(topic => topic.Id);
            entity.Property(topic => topic.Number).IsRequired();
            entity.Property(topic => topic.Subject).IsRequired().HasMaxLength(200);
            entity.HasMany(topic => topic.Exchanges)
                .WithOne(exchange => exchange.Topic)
                .HasForeignKey(exchange => exchange.TopicId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Exchange>(entity =>
        {
            entity.ToTable("Exchanges");
            entity.HasKey(exchange => exchange.Id);
            entity.HasMany(exchange => exchange.Procedures)
                .WithOne(procedure => procedure.Exchange)
                .HasForeignKey(procedure => procedure.ExchangeId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Procedure>(entity =>
        {
            entity.ToTable("Procedures");
            entity.HasKey(procedure => procedure.Id);
            entity.Property(procedure => procedure.Description).IsRequired().HasMaxLength(2000);
        });

        modelBuilder.Entity<SearchDocument>(entity =>
        {
            entity.HasKey(document => document.RowId);
            entity.ToTable("SearchDocuments", table => table.ExcludeFromMigrations());
            entity.Property(document => document.RowId).HasColumnName("rowid").ValueGeneratedNever();
            entity.Property(document => document.TopicNumber).HasColumnName("topic_number");
            entity.Property(document => document.TopicSubject).HasColumnName("topic_subject");
            entity.Property(document => document.ProcedureDescription).HasColumnName("procedure_description");
            entity.Property(document => document.Match)
                .HasColumnName("SearchDocuments")
                .ValueGeneratedOnAddOrUpdate();
            entity.Property(document => document.Rank)
                .HasColumnName("rank")
                .ValueGeneratedOnAddOrUpdate();
        });

        modelBuilder.Entity<Topic>().HasData(
            new Topic { Id = 1, Number = 1, Subject = "إجراءات تسجيل الطلاب" },
            new Topic { Id = 2, Number = 2, Subject = "إجراءات التخرج" });

        modelBuilder.Entity<Exchange>().HasData(
            new Exchange { Id = 1, TopicId = 1 },
            new Exchange { Id = 2, TopicId = 1 },
            new Exchange { Id = 3, TopicId = 2 });

        modelBuilder.Entity<Procedure>().HasData(
            new Procedure { Id = 1, ExchangeId = 1, Description = "مراجعة بيانات الطالب" },
            new Procedure { Id = 2, ExchangeId = 2, Description = "إضافة المستندات المطلوبة" },
            new Procedure { Id = 3, ExchangeId = 3, Description = "مراجعة متطلبات التخرج" });
    }
}
