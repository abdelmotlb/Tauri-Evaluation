using System.ComponentModel.DataAnnotations;

namespace dotnet.DTOs;

public sealed class ProcedureDto
{
    public int Id { get; init; }
    public int ExchangeId { get; init; }
    public string Description { get; init; } = string.Empty;
}

public sealed class CreateProcedureDto
{
    [Range(1, int.MaxValue)]
    public int ExchangeId { get; set; }

    [Required, StringLength(2000)]
    public string Description { get; set; } = string.Empty;
}

public sealed class UpdateProcedureDto
{
    [Range(1, int.MaxValue)]
    public int ExchangeId { get; set; }

    [Required, StringLength(2000)]
    public string Description { get; set; } = string.Empty;
}
