using System.ComponentModel.DataAnnotations;

namespace dotnet.DTOs;

public sealed class ExchangeDto
{
    public int Id { get; init; }
    public int TopicId { get; init; }
    public List<ProcedureDto> Procedures { get; init; } = [];
}

public sealed class CreateExchangeDto
{
    [Range(1, int.MaxValue)]
    public int TopicId { get; set; }
}

public sealed class UpdateExchangeDto
{
    [Range(1, int.MaxValue)]
    public int TopicId { get; set; }
}
