using System.ComponentModel.DataAnnotations;

namespace dotnet.DTOs;

public sealed class TopicDto
{
    public int Id { get; init; }
    public int Number { get; init; }
    public string Subject { get; init; } = string.Empty;
    public List<ExchangeDto> Exchanges { get; init; } = [];
}

public sealed class CreateTopicDto
{
    [Range(1, int.MaxValue)]
    public int Number { get; set; }

    [Required, StringLength(200)]
    public string Subject { get; set; } = string.Empty;
}

public sealed class UpdateTopicDto
{
    [Range(1, int.MaxValue)]
    public int Number { get; set; }

    [Required, StringLength(200)]
    public string Subject { get; set; } = string.Empty;
}
