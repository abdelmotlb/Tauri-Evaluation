namespace dotnet.Entities;

public class Exchange
{
    public int Id { get; set; }
    public int TopicId { get; set; }
    public Topic Topic { get; set; } = null!;
    public ICollection<Procedure> Procedures { get; set; } = new List<Procedure>();
}
