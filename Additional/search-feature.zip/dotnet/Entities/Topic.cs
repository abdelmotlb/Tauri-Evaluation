namespace dotnet.Entities;

public class Topic
{
    public int Id { get; set; }
    public int Number { get; set; }
    public string Subject { get; set; } = string.Empty;
    public ICollection<Exchange> Exchanges { get; set; } = new List<Exchange>();
}
