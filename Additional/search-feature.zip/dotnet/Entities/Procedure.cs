namespace dotnet.Entities;

public class Procedure
{
    public int Id { get; set; }
    public int ExchangeId { get; set; }
    public string Description { get; set; } = string.Empty;
    public Exchange Exchange { get; set; } = null!;
}
