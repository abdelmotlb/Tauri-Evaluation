# SQLite FTS5 Search

This document describes the FTS5 search feature, its source files, query semantics, and request flow. The C# files listed below are the source of truth; the excerpts show the important parts of the implementation.

## What is indexed

There is one FTS5 row for each `Procedure`.

| FTS5 column | Indexed? | Value |
| --- | --- | --- |
| `topic_number` | No | Parent Topic number, retained as metadata |
| `topic_subject` | Yes | Normalized parent Topic subject |
| `procedure_description` | Yes | Normalized Procedure description |
| FTS5 `rowid` | No | The relational Procedure ID |

The FTS5 virtual table is named `SearchDocuments`. Its schema is:

```sql
CREATE VIRTUAL TABLE SearchDocuments USING fts5(
    topic_number UNINDEXED,
    topic_subject,
    procedure_description,
    tokenize = 'unicode61'
);
```

The relational `Topics`, `Exchanges`, and `Procedures` tables remain authoritative. Search results return the current relational values rather than the normalized values stored in FTS.

The project uses `SQLitePCLRaw.lib.e_sqlite3` 2.1.12. The bundled native SQLite runtime was inspected: it reports SQLite 3.53.3, has FTS5 enabled, and supports the standard `unicode61` tokenizer used here. No Arabic-specific tokenizer is assumed.

## Request flow

```text
GET /api/search?q=...
        |
        v
SearchController
        |
        v
ISearchService -> SearchService
        |             |
        |             +-- IArabicTextNormalizer
        |             +-- AppDbContext.SearchDocuments (FTS5 MATCH + rank)
        |             +-- AppDbContext.Procedures (current result fields)
        v
SearchResult[]
```

### 1. Controller

[`SearchController.cs`](./Controllers/SearchController.cs) accepts the `q` query parameter and delegates the search. It contains no SQL or FTS-specific query logic.

```csharp
[ApiController]
[Route("api/search")]
public sealed class SearchController(ISearchService searchService) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<SearchResult>>> Search(
        [FromQuery(Name = "q")] string? query)
    {
        return Ok(await searchService.SearchAsync(query));
    }
}
```

### 2. Search contract and response

[`ISearchService.cs`](./Search/ISearchService.cs) defines the search operation. [`SearchResult.cs`](./Search/SearchResult.cs) is the API result shape.

```csharp
public interface ISearchService
{
    Task<IReadOnlyList<SearchResult>> SearchAsync(string? query);
}

public sealed class SearchResult
{
    public int TopicNumber { get; set; }
    public string TopicSubject { get; set; } = string.Empty;
    public string ProcedureDescription { get; set; } = string.Empty;
}
```

### 3. Arabic normalization

[`IArabicTextNormalizer.cs`](./Search/IArabicTextNormalizer.cs) and [`ArabicTextNormalizer.cs`](./Search/ArabicTextNormalizer.cs) provide the same normalization for indexed text and incoming search text.

The normalizer:

- Applies Unicode compatibility normalization (`FormKC`).
- Maps `أ`, `إ`, `آ`, and `ٱ` to `ا`.
- Removes Arabic diacritics and tatweel.
- Maps `ى` to `ي`, Persian `ک` to `ك`, and Persian `ی` to `ي`.
- Maps Arabic-Indic and Persian digits to Western digits; digits are preserved.
- Replaces punctuation and other separators with spaces and collapses whitespace.

It does not stem Arabic words or remove meaningful letters.

### 4. Query semantics and search

[`SearchService.cs`](./Search/SearchService.cs) performs these steps:

1. Treats null, empty, and whitespace-only input as no search and returns an empty result.
2. Removes a single pair of surrounding double quotes when supplied, marking the query as a phrase.
3. Normalizes and splits the query into terms.
4. For an ordinary query, quotes each normalized term and joins the terms with `AND`. All terms must match in the searchable FTS columns; token order is not significant.
5. For a quoted phrase, sends the normalized terms as one FTS phrase, requiring adjacent matching tokens.
6. Queries the mapped FTS5 table using its hidden `Match` column and orders by its hidden `Rank` column (FTS5's BM25 ranking; lower rank values are more relevant). No explicit column weights are configured, so FTS5's default weights apply equally to the two indexed text columns.
7. Uses the FTS rowids to load current Topic number, Topic subject, and Procedure description from the relational tables.

Numbers in a query are ordinary FTS text terms. They are **not** compared with the unindexed `topic_number` metadata. For example, `12` only matches if the token `12` occurs in a searchable subject or description.

The FTS expression is passed through EF Core's parameterized query translation. Each normal term is quoted; the query is not concatenated into raw SQL.

### 5. EF Core mapping for the virtual table

[`SearchDocument.cs`](./Search/SearchDocument.cs) maps the FTS columns, including FTS5's special columns:

```csharp
public sealed class SearchDocument
{
    public int RowId { get; set; }
    public int TopicNumber { get; set; }
    public string TopicSubject { get; set; } = string.Empty;
    public string ProcedureDescription { get; set; } = string.Empty;
    public string Match { get; set; } = string.Empty;
    public double? Rank { get; set; }
}
```

`Match` maps to a column whose name is the FTS table name (`SearchDocuments`). `Rank` maps to FTS5's hidden `rank` column. These mappings let `SearchService` use normal LINQ expressions for `MATCH` and relevance ordering.

The mapping is configured in [`AppDbContext.cs`](./Data/AppDbContext.cs). The virtual table is excluded from EF-generated relational table migrations because SQLite requires `CREATE VIRTUAL TABLE`.

### 6. Index creation, population, and rebuild

[`ISearchIndexService.cs`](./Search/ISearchIndexService.cs) exposes initialization and a full rebuild. [`SearchIndexService.cs`](./Search/SearchIndexService.cs) creates the virtual table if needed, then compares the FTS row count with the Procedure row count. If they differ, it rebuilds the index.

Rebuild behavior:

1. Delete all existing FTS rows (the FTS virtual table itself is retained).
2. Load Procedures through the existing generic `IRepository<Procedure>`, including their Exchange and Topic.
3. Normalize Topic subject and Procedure description.
4. Insert a row with `rowid = Procedure.Id` and parent Topic metadata.

The feature is initialized after EF migrations in [`Program.cs`](./Program.cs). Initialization creates the virtual table if it does not exist and rebuilds when the FTS row count differs from the relational Procedure count. The explicit `RebuildAsync()` method can also be called by resolving `ISearchIndexService` from dependency injection; use it to force a complete rebuild, including when external changes may have made the row contents stale without changing the row count.

### 7. Keeping the index synchronized

Existing create, update, and delete services commit through `IUnitOfWork.SaveChangesAsync()`. [`UnitOfWork.cs`](./Repositories/UnitOfWork.cs) wraps the relational save and index rebuild in one SQLite transaction:

```csharp
var transaction = await context.Database.BeginTransactionAsync();
await using (transaction)
{
    var savedCount = await context.SaveChangesAsync();
    await searchIndexService.RebuildAsync();
    await transaction.CommitAsync();
    return savedCount;
}
```

This straightforward full-rebuild strategy covers Procedure insert/update/delete, Topic subject/number changes, Procedure moves between Exchanges, Exchange moves between Topics, and cascading deletes. If saving or rebuilding fails, the transaction does not commit either change.

The trade-off is that every Unit of Work save rebuilds the complete index. This is simple and reliable for the current small demonstration data set, but should be replaced by incremental updates if the index grows substantially.

### 8. Migration and startup

[`20260929155510_AddSearchDocuments.cs`](./Migrations/20260929155510_AddSearchDocuments.cs) creates the FTS5 virtual table. At startup, [`Program.cs`](./Program.cs):

1. Registers the EF Core SQLite context and search services.
2. Applies EF Core migrations with `Database.MigrateAsync()`.
3. Resolves `ISearchIndexService` and calls `InitializeAsync()` to create/repopulate the FTS table when needed.

The configured SQLite database path is in [`appsettings.json`](./appsettings.json).

## Files for this feature

- Controller: [`Controllers/SearchController.cs`](./Controllers/SearchController.cs)
- Search contract and implementation: [`Search/ISearchService.cs`](./Search/ISearchService.cs), [`Search/SearchService.cs`](./Search/SearchService.cs)
- Search result and FTS mapping: [`Search/SearchResult.cs`](./Search/SearchResult.cs), [`Search/SearchDocument.cs`](./Search/SearchDocument.cs)
- Arabic normalization: [`Search/IArabicTextNormalizer.cs`](./Search/IArabicTextNormalizer.cs), [`Search/ArabicTextNormalizer.cs`](./Search/ArabicTextNormalizer.cs)
- Index lifecycle: [`Search/ISearchIndexService.cs`](./Search/ISearchIndexService.cs), [`Search/SearchIndexService.cs`](./Search/SearchIndexService.cs)
- EF mapping: [`Data/AppDbContext.cs`](./Data/AppDbContext.cs)
- Save/index synchronization: [`Repositories/UnitOfWork.cs`](./Repositories/UnitOfWork.cs)
- DI, migrations, and initialization: [`Program.cs`](./Program.cs), [`Migrations/20260929155510_AddSearchDocuments.cs`](./Migrations/20260929155510_AddSearchDocuments.cs)
- Tests: [`Tests/SearchServiceTests.cs`](./Tests/SearchServiceTests.cs)

## Calling the endpoint

```http
GET /api/search?q=إجراءات%20تسجيل
```

Example JSON response:

```json
[
  {
    "topicNumber": 1,
    "topicSubject": "إجراءات تسجيل الطلاب",
    "procedureDescription": "مراجعة بيانات الطالب"
  }
]
```

Quotes request a phrase:

```http
GET /api/search?q=%22مراجعة%20بيانات%22
```

Digits are searchable as ordinary content. For example, `123` or `مراجعة 123` can match a description containing `123`; a query for `12` does not match a Topic merely because its `Number` is 12.

Run the focused search tests with:

```powershell
dotnet test .\Tests\SearchService.Tests.csproj
```
