using System.Linq.Expressions;

namespace dotnet.Repositories;

public interface IRepository<T> where T : class
{
    Task<T?> GetByIdAsync(
        int id,
        Func<IQueryable<T>, IQueryable<T>>? include = null);

    Task<List<T>> GetAllAsync(Func<IQueryable<T>, IQueryable<T>>? include = null);

    Task<List<T>> FindAsync(
        Expression<Func<T, bool>> predicate,
        Func<IQueryable<T>, IQueryable<T>>? include = null);

    Task<bool> AnyAsync(Expression<Func<T, bool>> predicate);

    Task<int> CountAsync(Expression<Func<T, bool>>? predicate = null);

    Task AddAsync(T entity);
    void Update(T entity);
    void Remove(T entity);
}
