using dotnet.Data;
using dotnet.Search;

namespace dotnet.Repositories;

public sealed class UnitOfWork(
    IServiceProvider serviceProvider,
    AppDbContext context,
    ISearchIndexService searchIndexService) : IUnitOfWork
{
    private readonly Dictionary<Type, object> _repositories = new();

    public IRepository<T> Repository<T>() where T : class
    {
        if (_repositories.TryGetValue(typeof(T), out var repository))
        {
            return (IRepository<T>)repository;
        }

        var createdRepository = serviceProvider.GetRequiredService<IRepository<T>>();
        _repositories.Add(typeof(T), createdRepository);
        return createdRepository;
    }

    public Task<int> SaveChangesAsync()
    {
        return SaveAndSynchronizeAsync();
    }

    private async Task<int> SaveAndSynchronizeAsync()
    {
        var transaction = await context.Database.BeginTransactionAsync();
        await using (transaction)
        {
            var savedCount = await context.SaveChangesAsync();
            await searchIndexService.RebuildAsync();
            await transaction.CommitAsync();
            return savedCount;
        }
    }
}
