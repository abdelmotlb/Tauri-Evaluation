using dotnet.DTOs;

namespace dotnet.Services;

public interface IProcedureService
{
    Task<List<ProcedureDto>> GetAllAsync();
    Task<ProcedureDto?> GetByIdAsync(int id);
    Task<ProcedureDto?> CreateAsync(CreateProcedureDto request);
    Task<ProcedureDto?> UpdateAsync(int id, UpdateProcedureDto request);
    Task<bool> DeleteAsync(int id);
}
