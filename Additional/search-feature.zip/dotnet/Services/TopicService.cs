using dotnet.DTOs;
using dotnet.Entities;
using dotnet.Repositories;
using Microsoft.EntityFrameworkCore;

namespace dotnet.Services;

public sealed class TopicService(IUnitOfWork unitOfWork) : ITopicService
{
    private IRepository<Topic> Topics => unitOfWork.Repository<Topic>();

    public async Task<List<TopicDto>> GetAllAsync()
    {
        var topics = await Topics.GetAllAsync(
            query => query.Include(topic => topic.Exchanges).ThenInclude(exchange => exchange.Procedures));
        return topics.Select(ToDto).ToList();
    }

    public async Task<TopicDto?> GetByIdAsync(int id)
    {
        var topic = await Topics.GetByIdAsync(
            id,
            query => query.Include(entity => entity.Exchanges).ThenInclude(exchange => exchange.Procedures));
        return topic is null ? null : ToDto(topic);
    }

    public async Task<TopicDto> CreateAsync(CreateTopicDto request)
    {
        var topic = new Topic { Number = request.Number, Subject = request.Subject.Trim() };
        await Topics.AddAsync(topic);
        await unitOfWork.SaveChangesAsync();
        return ToDto(topic);
    }

    public async Task<TopicDto?> UpdateAsync(int id, UpdateTopicDto request)
    {
        var topic = await Topics.GetByIdAsync(id);
        if (topic is null)
        {
            return null;
        }

        topic.Number = request.Number;
        topic.Subject = request.Subject.Trim();
        Topics.Update(topic);
        await unitOfWork.SaveChangesAsync();
        return ToDto(topic);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var topic = await Topics.GetByIdAsync(id);
        if (topic is null)
        {
            return false;
        }

        Topics.Remove(topic);
        await unitOfWork.SaveChangesAsync();
        return true;
    }

    private static TopicDto ToDto(Topic topic) => new()
    {
        Id = topic.Id,
        Number = topic.Number,
        Subject = topic.Subject,
        Exchanges = topic.Exchanges.Select(exchange => new ExchangeDto
        {
            Id = exchange.Id,
            TopicId = exchange.TopicId,
            Procedures = exchange.Procedures.Select(procedure => new ProcedureDto
            {
                Id = procedure.Id,
                ExchangeId = procedure.ExchangeId,
                Description = procedure.Description
            }).ToList()
        }).ToList()
    };
}
