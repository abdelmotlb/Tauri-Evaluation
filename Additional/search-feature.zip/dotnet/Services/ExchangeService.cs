using dotnet.DTOs;
using dotnet.Entities;
using dotnet.Repositories;
using Microsoft.EntityFrameworkCore;

namespace dotnet.Services;

public sealed class ExchangeService(IUnitOfWork unitOfWork) : IExchangeService
{
    private IRepository<Exchange> Exchanges => unitOfWork.Repository<Exchange>();

    public async Task<List<ExchangeDto>> GetAllAsync()
    {
        var exchanges = await Exchanges.GetAllAsync(
            query => query.Include(exchange => exchange.Procedures));
        return exchanges.Select(ToDto).ToList();
    }

    public async Task<ExchangeDto?> GetByIdAsync(int id)
    {
        var exchange = await Exchanges.GetByIdAsync(
            id,
            query => query.Include(entity => entity.Procedures));
        return exchange is null ? null : ToDto(exchange);
    }

    public async Task<ExchangeDto?> CreateAsync(CreateExchangeDto request)
    {
        if (!await unitOfWork.Repository<Topic>().AnyAsync(topic => topic.Id == request.TopicId))
        {
            return null;
        }

        var exchange = new Exchange { TopicId = request.TopicId };
        await Exchanges.AddAsync(exchange);
        await unitOfWork.SaveChangesAsync();
        return ToDto(exchange);
    }

    public async Task<ExchangeDto?> UpdateAsync(int id, UpdateExchangeDto request)
    {
        var exchange = await Exchanges.GetByIdAsync(id);
        if (exchange is null || !await unitOfWork.Repository<Topic>().AnyAsync(topic => topic.Id == request.TopicId))
        {
            return null;
        }

        exchange.TopicId = request.TopicId;
        Exchanges.Update(exchange);
        await unitOfWork.SaveChangesAsync();
        return ToDto(exchange);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var exchange = await Exchanges.GetByIdAsync(id);
        if (exchange is null)
        {
            return false;
        }

        Exchanges.Remove(exchange);
        await unitOfWork.SaveChangesAsync();
        return true;
    }

    private static ExchangeDto ToDto(Exchange exchange) => new()
    {
        Id = exchange.Id,
        TopicId = exchange.TopicId,
        Procedures = exchange.Procedures.Select(procedure => new ProcedureDto
        {
            Id = procedure.Id,
            ExchangeId = procedure.ExchangeId,
            Description = procedure.Description
        }).ToList()
    };
}
