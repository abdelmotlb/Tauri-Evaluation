using dotnet.DTOs;

namespace dotnet.Services;

public interface ITopicService
{
    Task<List<TopicDto>> GetAllAsync();
    Task<TopicDto?> GetByIdAsync(int id);
    Task<TopicDto> CreateAsync(CreateTopicDto request);
    Task<TopicDto?> UpdateAsync(int id, UpdateTopicDto request);
    Task<bool> DeleteAsync(int id);
}
