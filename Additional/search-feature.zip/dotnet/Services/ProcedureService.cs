using dotnet.DTOs;
using dotnet.Entities;
using dotnet.Repositories;

namespace dotnet.Services;

public sealed class ProcedureService(IUnitOfWork unitOfWork) : IProcedureService
{
    private IRepository<Procedure> Procedures => unitOfWork.Repository<Procedure>();

    public async Task<List<ProcedureDto>> GetAllAsync()
    {
        var procedures = await Procedures.GetAllAsync();
        return procedures.Select(ToDto).ToList();
    }

    public async Task<ProcedureDto?> GetByIdAsync(int id)
    {
        var procedure = await Procedures.GetByIdAsync(id);
        return procedure is null ? null : ToDto(procedure);
    }

    public async Task<ProcedureDto?> CreateAsync(CreateProcedureDto request)
    {
        if (!await unitOfWork.Repository<Exchange>().AnyAsync(exchange => exchange.Id == request.ExchangeId))
        {
            return null;
        }

        var procedure = new Procedure
        {
            ExchangeId = request.ExchangeId,
            Description = request.Description.Trim()
        };
        await Procedures.AddAsync(procedure);
        await unitOfWork.SaveChangesAsync();
        return ToDto(procedure);
    }

    public async Task<ProcedureDto?> UpdateAsync(int id, UpdateProcedureDto request)
    {
        var procedure = await Procedures.GetByIdAsync(id);
        if (procedure is null || !await unitOfWork.Repository<Exchange>().AnyAsync(exchange => exchange.Id == request.ExchangeId))
        {
            return null;
        }

        procedure.ExchangeId = request.ExchangeId;
        procedure.Description = request.Description.Trim();
        Procedures.Update(procedure);
        await unitOfWork.SaveChangesAsync();
        return ToDto(procedure);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var procedure = await Procedures.GetByIdAsync(id);
        if (procedure is null)
        {
            return false;
        }

        Procedures.Remove(procedure);
        await unitOfWork.SaveChangesAsync();
        return true;
    }

    private static ProcedureDto ToDto(Procedure procedure) => new()
    {
        Id = procedure.Id,
        ExchangeId = procedure.ExchangeId,
        Description = procedure.Description
    };
}
