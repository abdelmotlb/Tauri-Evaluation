using dotnet.DTOs;

namespace dotnet.Services;

public interface IExchangeService
{
    Task<List<ExchangeDto>> GetAllAsync();
    Task<ExchangeDto?> GetByIdAsync(int id);
    Task<ExchangeDto?> CreateAsync(CreateExchangeDto request);
    Task<ExchangeDto?> UpdateAsync(int id, UpdateExchangeDto request);
    Task<bool> DeleteAsync(int id);
}
