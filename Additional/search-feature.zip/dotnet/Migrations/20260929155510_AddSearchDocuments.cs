﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace dotnet.Migrations
{
    /// <inheritdoc />
    public partial class AddSearchDocuments : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP TABLE IF EXISTS search_fts;");
            migrationBuilder.Sql(
                """
                CREATE VIRTUAL TABLE SearchDocuments USING fts5(
                    topic_number UNINDEXED,
                    topic_subject,
                    procedure_description,
                    tokenize = 'unicode61'
                );
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP TABLE IF EXISTS SearchDocuments;");
        }
    }
}
