using dotnet.Data;
using dotnet.Entities;
using dotnet.Search;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace dotnet.Tests;

public sealed class SearchServiceTests
{
    [Fact]
    public async Task SearchAsync_TopicText_ReturnsEveryProcedureUnderMatchingTopic()
    {
        await using var fixture = await SearchFixture.CreateAsync();

        var results = await fixture.SearchService.SearchAsync("إجراءات التسجيل");

        Assert.Equal(2, results.Count);
        Assert.All(results, result =>
        {
            Assert.Equal(12, result.TopicNumber);
            Assert.Equal("إِجْرَاءَاتـ التسجيل", result.TopicSubject);
        });
    }

    [Fact]
    public async Task SearchAsync_ProcedureText_ReturnsOnlyMatchingProcedureWithTopic()
    {
        await using var fixture = await SearchFixture.CreateAsync();

        var results = await fixture.SearchService.SearchAsync("مراجعة الطالب");

        var result = Assert.Single(results);
        Assert.Equal(12, result.TopicNumber);
        Assert.Equal("إِجْرَاءَاتـ التسجيل", result.TopicSubject);
        Assert.Equal("مراجعة الطالب 123 الجديدة", result.ProcedureDescription);
    }

    [Fact]
    public async Task SearchAsync_NumberOnly_MatchesSearchableTextRatherThanTopicNumber()
    {
        await using var fixture = await SearchFixture.CreateAsync();

        var results = await fixture.SearchService.SearchAsync("12");

        Assert.Empty(results);
    }

    [Fact]
    public async Task SearchAsync_NumberWithText_MatchesNumberInSearchableText()
    {
        await using var fixture = await SearchFixture.CreateAsync();

        var results = await fixture.SearchService.SearchAsync("مراجعة 123");

        var result = Assert.Single(results);
        Assert.Equal("مراجعة الطالب 123 الجديدة", result.ProcedureDescription);
    }

    [Fact]
    public async Task SearchAsync_NumberInProcedureDescription_PreservesNumber()
    {
        await using var fixture = await SearchFixture.CreateAsync();

        var results = await fixture.SearchService.SearchAsync("123");

        var result = Assert.Single(results);
        Assert.Equal("مراجعة الطالب 123 الجديدة", result.ProcedureDescription);
    }

    [Fact]
    public async Task SearchAsync_QuotedPhrase_ReturnsAdjacentTermsOnly()
    {
        await using var fixture = await SearchFixture.CreateAsync();

        var results = await fixture.SearchService.SearchAsync("\"مراجعة الطالب\"");

        var result = Assert.Single(results);
        Assert.Equal("مراجعة الطالب 123 الجديدة", result.ProcedureDescription);
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData("* : ^ { }")]
    [InlineData("term-that-does-not-exist")]
    public async Task SearchAsync_EmptyOrInvalidQuery_ReturnsNoResults(string query)
    {
        await using var fixture = await SearchFixture.CreateAsync();

        var results = await fixture.SearchService.SearchAsync(query);

        Assert.Empty(results);
    }

    [Fact]
    public async Task SearchAsync_NullQuery_ReturnsNoResults()
    {
        await using var fixture = await SearchFixture.CreateAsync();

        var results = await fixture.SearchService.SearchAsync(null);

        Assert.Empty(results);
    }

    private sealed class SearchFixture : IAsyncDisposable
    {
        private readonly SqliteConnection _connection;
        private readonly AppDbContext _dbContext;

        private SearchFixture(SqliteConnection connection, AppDbContext dbContext)
        {
            _connection = connection;
            _dbContext = dbContext;
            SearchService = new SearchService(dbContext, new ArabicTextNormalizer());
        }

        public SearchService SearchService { get; }

        public static async Task<SearchFixture> CreateAsync()
        {
            var connection = new SqliteConnection("Data Source=:memory:");
            await connection.OpenAsync();

            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlite(connection)
                .Options;
            var dbContext = new AppDbContext(options);
            await dbContext.Database.EnsureCreatedAsync();
            await dbContext.Database.ExecuteSqlRawAsync(
                """
                CREATE VIRTUAL TABLE SearchDocuments USING fts5(
                    topic_number UNINDEXED,
                    topic_subject,
                    procedure_description,
                    tokenize = 'unicode61'
                );
                """);

            var topic = new Topic { Number = 12, Subject = "إِجْرَاءَاتـ التسجيل" };
            var firstExchange = new Exchange { Topic = topic };
            var secondExchange = new Exchange { Topic = topic };
            var matchingProcedure = new Procedure
            {
                Exchange = firstExchange,
                Description = "مراجعة الطالب 123 الجديدة"
            };
            var otherProcedure = new Procedure
            {
                Exchange = secondExchange,
                Description = "إضافة المستندات المطلوبة"
            };

            dbContext.AddRange(topic, firstExchange, secondExchange, matchingProcedure, otherProcedure);
            await dbContext.SaveChangesAsync();

            var normalizer = new ArabicTextNormalizer();
            await InsertIndexRowAsync(dbContext, topic, matchingProcedure, normalizer);
            await InsertIndexRowAsync(dbContext, topic, otherProcedure, normalizer);

            return new SearchFixture(connection, dbContext);
        }

        public async ValueTask DisposeAsync()
        {
            await _dbContext.DisposeAsync();
            await _connection.DisposeAsync();
        }

        private static Task<int> InsertIndexRowAsync(
            AppDbContext dbContext,
            Topic topic,
            Procedure procedure,
            IArabicTextNormalizer normalizer)
        {
            return dbContext.Database.ExecuteSqlInterpolatedAsync(
                $"""
                INSERT INTO SearchDocuments (rowid, topic_number, topic_subject, procedure_description)
                VALUES (
                    {procedure.Id},
                    {topic.Number},
                    {normalizer.Normalize(topic.Subject)},
                    {normalizer.Normalize(procedure.Description)}
                );
                """);
        }
    }
}
