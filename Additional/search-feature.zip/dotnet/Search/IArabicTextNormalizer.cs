namespace dotnet.Search;

public interface IArabicTextNormalizer
{
    string Normalize(string? text);
}
