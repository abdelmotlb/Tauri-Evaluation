namespace dotnet.Search;

public interface ISearchIndexService
{
    Task InitializeAsync();
    Task RebuildAsync();
}
