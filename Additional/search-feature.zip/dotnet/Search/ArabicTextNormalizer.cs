using System.Globalization;
using System.Text;

namespace dotnet.Search;

public sealed class ArabicTextNormalizer : IArabicTextNormalizer
{
    public string Normalize(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return string.Empty;
        }

        var normalized = text.Normalize(NormalizationForm.FormKC);
        var result = new StringBuilder(normalized.Length);
        var previousWasWhitespace = true;

        foreach (var rune in normalized.EnumerateRunes())
        {
            var value = rune.Value;
            if (value == 0x0640)
            {
                continue;
            }

            if (Rune.GetUnicodeCategory(rune) is
                UnicodeCategory.NonSpacingMark or
                UnicodeCategory.SpacingCombiningMark or
                UnicodeCategory.EnclosingMark or
                UnicodeCategory.Format)
            {
                continue;
            }

            value = value switch
            {
                0x0622 or 0x0623 or 0x0625 or 0x0671 => 0x0627,
                0x0649 => 0x064A,
                0x06A9 => 0x0643,
                0x06CC => 0x064A,
                >= 0x0660 and <= 0x0669 => '0' + (value - 0x0660),
                >= 0x06F0 and <= 0x06F9 => '0' + (value - 0x06F0),
                _ => value
            };

            var mappedRune = new Rune(value);
            var category = Rune.GetUnicodeCategory(mappedRune);
            if (category is UnicodeCategory.UppercaseLetter
                or UnicodeCategory.LowercaseLetter
                or UnicodeCategory.TitlecaseLetter
                or UnicodeCategory.ModifierLetter
                or UnicodeCategory.OtherLetter
                or UnicodeCategory.DecimalDigitNumber
                or UnicodeCategory.LetterNumber
                or UnicodeCategory.OtherNumber)
            {
                result.Append(mappedRune);
                previousWasWhitespace = false;
            }
            else if (!previousWasWhitespace)
            {
                result.Append(' ');
                previousWasWhitespace = true;
            }
        }

        return result.ToString().Trim();
    }
}
