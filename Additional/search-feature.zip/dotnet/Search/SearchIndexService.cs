using dotnet.Data;
using dotnet.Entities;
using dotnet.Repositories;
using Microsoft.EntityFrameworkCore;

namespace dotnet.Search;

public sealed class SearchIndexService(
    AppDbContext dbContext,
    IRepository<Procedure> procedureRepository,
    IArabicTextNormalizer normalizer) : ISearchIndexService
{
    public async Task InitializeAsync()
    {
        await dbContext.Database.ExecuteSqlRawAsync(
            """
            CREATE VIRTUAL TABLE IF NOT EXISTS SearchDocuments USING fts5(
                topic_number UNINDEXED,
                topic_subject,
                procedure_description,
                tokenize = 'unicode61'
            );
            """);

        if (await dbContext.SearchDocuments.CountAsync() !=
            await dbContext.Procedures.CountAsync())
        {
            await RebuildAsync();
        }
    }

    public async Task RebuildAsync()
    {
        await dbContext.Database.ExecuteSqlRawAsync("DELETE FROM SearchDocuments;");

        var procedures = await procedureRepository.GetAllAsync(query => query
            .AsNoTracking()
            .Include(procedure => procedure.Exchange)
            .ThenInclude(exchange => exchange.Topic));

        foreach (var procedure in procedures)
        {
            await dbContext.Database.ExecuteSqlInterpolatedAsync(
                $"""
                INSERT INTO SearchDocuments (rowid, topic_number, topic_subject, procedure_description)
                VALUES (
                    {procedure.Id},
                    {procedure.Exchange.Topic.Number},
                    {normalizer.Normalize(procedure.Exchange.Topic.Subject)},
                    {normalizer.Normalize(procedure.Description)}
                );
                """);
        }
    }
}
