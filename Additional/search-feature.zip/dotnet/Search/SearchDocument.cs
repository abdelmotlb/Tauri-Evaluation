namespace dotnet.Search;

public sealed class SearchDocument
{
    public int RowId { get; set; }
    public int TopicNumber { get; set; }
    public string TopicSubject { get; set; } = string.Empty;
    public string ProcedureDescription { get; set; } = string.Empty;
    public string Match { get; set; } = string.Empty;
    public double? Rank { get; set; }
}
