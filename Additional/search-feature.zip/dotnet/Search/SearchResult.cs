namespace dotnet.Search;

public sealed class SearchResult
{
    public int TopicNumber { get; set; }
    public string TopicSubject { get; set; } = string.Empty;
    public string ProcedureDescription { get; set; } = string.Empty;
}
