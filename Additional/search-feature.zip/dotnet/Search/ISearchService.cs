namespace dotnet.Search;

public interface ISearchService
{
    Task<IReadOnlyList<SearchResult>> SearchAsync(string? query);
}
