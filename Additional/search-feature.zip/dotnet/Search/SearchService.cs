using dotnet.Data;
using Microsoft.EntityFrameworkCore;

namespace dotnet.Search;

public sealed class SearchService(
    AppDbContext dbContext,
    IArabicTextNormalizer normalizer) : ISearchService
{
    public async Task<IReadOnlyList<SearchResult>> SearchAsync(string? query)
    {
        var queryText = query?.Trim() ?? string.Empty;
        var isPhrase = queryText.Length >= 2 &&
            queryText.StartsWith('"') &&
            queryText.EndsWith('"');
        if (isPhrase)
        {
            queryText = queryText[1..^1];
        }

        var terms = normalizer.Normalize(queryText)
            .Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (terms.Length == 0)
        {
            return [];
        }

        var ftsQuery = isPhrase
            ? $"\"{string.Join(" ", terms)}\""
            : string.Join(" AND ", terms.Select(Quote));
        var procedureIds = await dbContext.SearchDocuments
            .Where(document => document.Match == ftsQuery)
            .OrderBy(document => document.Rank)
            .Select(document => document.RowId)
            .ToListAsync();
        var documentsById = await dbContext.Procedures
            .AsNoTracking()
            .Where(procedure => procedureIds.Contains(procedure.Id))
            .Select(procedure => new
            {
                procedure.Id,
                TopicNumber = procedure.Exchange.Topic.Number,
                TopicSubject = procedure.Exchange.Topic.Subject,
                ProcedureDescription = procedure.Description
            })
            .ToListAsync();

        var orderedResults = documentsById.ToDictionary(
            item => item.Id,
            item => new SearchResult
            {
                TopicNumber = item.TopicNumber,
                TopicSubject = item.TopicSubject,
                ProcedureDescription = item.ProcedureDescription
            });

        return procedureIds
            .Where(orderedResults.ContainsKey)
            .Select(id => orderedResults[id])
            .ToList();
    }

    private static string Quote(string term) => $"\"{term.Replace("\"", "\"\"")}\"";
}