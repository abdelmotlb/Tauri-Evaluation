using dotnet.DTOs;
using dotnet.Services;
using Microsoft.AspNetCore.Mvc;

namespace dotnet.Controllers;

[ApiController]
[Route("api/topics")]
public sealed class TopicsController(ITopicService topicService) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<List<TopicDto>>> GetAll() =>
        Ok(await topicService.GetAllAsync());

    [HttpGet("{id:int}")]
    public async Task<ActionResult<TopicDto>> GetById(int id)
    {
        var topic = await topicService.GetByIdAsync(id);
        return topic is null ? NotFound() : Ok(topic);
    }

    [HttpPost]
    public async Task<ActionResult<TopicDto>> Create(CreateTopicDto request)
    {
        var topic = await topicService.CreateAsync(request);
        return CreatedAtAction(nameof(GetById), new { id = topic.Id }, topic);
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<TopicDto>> Update(int id, UpdateTopicDto request)
    {
        var topic = await topicService.UpdateAsync(id, request);
        return topic is null ? NotFound() : Ok(topic);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id) =>
        await topicService.DeleteAsync(id) ? NoContent() : NotFound();
}
