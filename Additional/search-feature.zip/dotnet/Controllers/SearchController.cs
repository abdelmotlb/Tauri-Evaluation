using dotnet.Search;
using Microsoft.AspNetCore.Mvc;

namespace dotnet.Controllers;

[ApiController]
[Route("api/search")]
public sealed class SearchController(ISearchService searchService) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<SearchResult>>> Search([FromQuery(Name = "q")] string? query)
    {
        return Ok(await searchService.SearchAsync(query));
    }
}
