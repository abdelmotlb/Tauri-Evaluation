using dotnet.DTOs;
using dotnet.Services;
using Microsoft.AspNetCore.Mvc;

namespace dotnet.Controllers;

[ApiController]
[Route("api/exchanges")]
public sealed class ExchangesController(IExchangeService exchangeService) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<List<ExchangeDto>>> GetAll() =>
        Ok(await exchangeService.GetAllAsync());

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ExchangeDto>> GetById(int id)
    {
        var exchange = await exchangeService.GetByIdAsync(id);
        return exchange is null ? NotFound() : Ok(exchange);
    }

    [HttpPost]
    public async Task<ActionResult<ExchangeDto>> Create(CreateExchangeDto request)
    {
        var exchange = await exchangeService.CreateAsync(request);
        return exchange is null
            ? BadRequest(new { error = "The specified topic does not exist." })
            : CreatedAtAction(nameof(GetById), new { id = exchange.Id }, exchange);
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<ExchangeDto>> Update(int id, UpdateExchangeDto request)
    {
        var exchange = await exchangeService.UpdateAsync(id, request);
        return exchange is null ? NotFound() : Ok(exchange);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id) =>
        await exchangeService.DeleteAsync(id) ? NoContent() : NotFound();
}
