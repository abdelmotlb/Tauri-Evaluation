using dotnet.DTOs;
using dotnet.Services;
using Microsoft.AspNetCore.Mvc;

namespace dotnet.Controllers;

[ApiController]
[Route("api/procedures")]
public sealed class ProceduresController(IProcedureService procedureService) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<List<ProcedureDto>>> GetAll() =>
        Ok(await procedureService.GetAllAsync());

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ProcedureDto>> GetById(int id)
    {
        var procedure = await procedureService.GetByIdAsync(id);
        return procedure is null ? NotFound() : Ok(procedure);
    }

    [HttpPost]
    public async Task<ActionResult<ProcedureDto>> Create(CreateProcedureDto request)
    {
        var procedure = await procedureService.CreateAsync(request);
        return procedure is null
            ? BadRequest(new { error = "The specified exchange does not exist." })
            : CreatedAtAction(nameof(GetById), new { id = procedure.Id }, procedure);
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<ProcedureDto>> Update(int id, UpdateProcedureDto request)
    {
        var procedure = await procedureService.UpdateAsync(id, request);
        return procedure is null ? NotFound() : Ok(procedure);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id) =>
        await procedureService.DeleteAsync(id) ? NoContent() : NotFound();
}
